from kptgraphs import BasicGraphs
from kptgraphs import ColorSchemes
from kptgraphs import Basics
